﻿namespace QuanLyBanHang
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.hệThốngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cấuHìnhHệThốngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýNgườiDùngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngNhậpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đổiMậtKhẩuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xemDanhMụcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhMụcThànhPhốToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhMụcKháchHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhMụcNhânViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhMụcSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhMụcHóaĐơnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhMụcChiTiếtHóaĐơnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýDanhMụcĐơnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhMụcThànhPhốToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.danhMụcKháchHàngToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.danhMụcNhânViênToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.danhMụcSảnPhẩmToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.danhMụcHóaĐơnToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.danhMụcChiTiếtHóaĐơnToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýDanhMụcTheoNhómToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.giúpĐỡToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hướngDẫnSửDụngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tácGiảToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kháchHàngTheoThànhPhốToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hóaĐơnTheoKháchHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hóaĐơnTheoSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hóaĐơnTheoNhânViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chiTiếtHóaĐơnTheoHóaĐơnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(149, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(339, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "ỨNG DỤNG QUẢN LÝ BÁN HÀNG";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hệThốngToolStripMenuItem,
            this.xemDanhMụcToolStripMenuItem,
            this.quảnLýDanhMụcĐơnToolStripMenuItem,
            this.quảnLýDanhMụcTheoNhómToolStripMenuItem,
            this.giúpĐỡToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(652, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // hệThốngToolStripMenuItem
            // 
            this.hệThốngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cấuHìnhHệThốngToolStripMenuItem,
            this.quảnLýNgườiDùngToolStripMenuItem,
            this.đăngNhậpToolStripMenuItem,
            this.đổiMậtKhẩuToolStripMenuItem,
            this.thoátToolStripMenuItem});
            this.hệThốngToolStripMenuItem.Name = "hệThốngToolStripMenuItem";
            this.hệThốngToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.hệThốngToolStripMenuItem.Text = "Hệ thống";
            // 
            // cấuHìnhHệThốngToolStripMenuItem
            // 
            this.cấuHìnhHệThốngToolStripMenuItem.Name = "cấuHìnhHệThốngToolStripMenuItem";
            this.cấuHìnhHệThốngToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.cấuHìnhHệThốngToolStripMenuItem.Text = "Cấu hình hệ thống";
            // 
            // quảnLýNgườiDùngToolStripMenuItem
            // 
            this.quảnLýNgườiDùngToolStripMenuItem.Name = "quảnLýNgườiDùngToolStripMenuItem";
            this.quảnLýNgườiDùngToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.quảnLýNgườiDùngToolStripMenuItem.Text = "Quản lý người dùng";
            // 
            // đăngNhậpToolStripMenuItem
            // 
            this.đăngNhậpToolStripMenuItem.Name = "đăngNhậpToolStripMenuItem";
            this.đăngNhậpToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.đăngNhậpToolStripMenuItem.Text = "Đăng nhập";
            this.đăngNhậpToolStripMenuItem.Click += new System.EventHandler(this.đăngNhậpToolStripMenuItem_Click);
            // 
            // đổiMậtKhẩuToolStripMenuItem
            // 
            this.đổiMậtKhẩuToolStripMenuItem.Name = "đổiMậtKhẩuToolStripMenuItem";
            this.đổiMậtKhẩuToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.đổiMậtKhẩuToolStripMenuItem.Text = "Đổi mật khẩu";
            // 
            // thoátToolStripMenuItem
            // 
            this.thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            this.thoátToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.thoátToolStripMenuItem.Text = "Thoát";
            this.thoátToolStripMenuItem.Click += new System.EventHandler(this.thoátToolStripMenuItem_Click);
            // 
            // xemDanhMụcToolStripMenuItem
            // 
            this.xemDanhMụcToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.danhMụcThànhPhốToolStripMenuItem,
            this.danhMụcKháchHàngToolStripMenuItem,
            this.danhMụcNhânViênToolStripMenuItem,
            this.danhMụcSảnPhẩmToolStripMenuItem,
            this.danhMụcHóaĐơnToolStripMenuItem,
            this.danhMụcChiTiếtHóaĐơnToolStripMenuItem});
            this.xemDanhMụcToolStripMenuItem.Name = "xemDanhMụcToolStripMenuItem";
            this.xemDanhMụcToolStripMenuItem.Size = new System.Drawing.Size(101, 20);
            this.xemDanhMụcToolStripMenuItem.Text = "Xem Danh mục";
            // 
            // danhMụcThànhPhốToolStripMenuItem
            // 
            this.danhMụcThànhPhốToolStripMenuItem.Name = "danhMụcThànhPhốToolStripMenuItem";
            this.danhMụcThànhPhốToolStripMenuItem.Size = new System.Drawing.Size(217, 22);
            this.danhMụcThànhPhốToolStripMenuItem.Text = "Danh mục Thành phố";
            this.danhMụcThànhPhốToolStripMenuItem.Click += new System.EventHandler(this.danhMụcThànhPhốToolStripMenuItem_Click);
            // 
            // danhMụcKháchHàngToolStripMenuItem
            // 
            this.danhMụcKháchHàngToolStripMenuItem.Name = "danhMụcKháchHàngToolStripMenuItem";
            this.danhMụcKháchHàngToolStripMenuItem.Size = new System.Drawing.Size(217, 22);
            this.danhMụcKháchHàngToolStripMenuItem.Text = "Danh mục Khách hàng";
            this.danhMụcKháchHàngToolStripMenuItem.Click += new System.EventHandler(this.danhMụcKháchHàngToolStripMenuItem_Click);
            // 
            // danhMụcNhânViênToolStripMenuItem
            // 
            this.danhMụcNhânViênToolStripMenuItem.Name = "danhMụcNhânViênToolStripMenuItem";
            this.danhMụcNhânViênToolStripMenuItem.Size = new System.Drawing.Size(217, 22);
            this.danhMụcNhânViênToolStripMenuItem.Text = "Danh mục Nhân viên";
            this.danhMụcNhânViênToolStripMenuItem.Click += new System.EventHandler(this.danhMụcNhânViênToolStripMenuItem_Click);
            // 
            // danhMụcSảnPhẩmToolStripMenuItem
            // 
            this.danhMụcSảnPhẩmToolStripMenuItem.Name = "danhMụcSảnPhẩmToolStripMenuItem";
            this.danhMụcSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(217, 22);
            this.danhMụcSảnPhẩmToolStripMenuItem.Text = "Danh mục Sản phẩm";
            this.danhMụcSảnPhẩmToolStripMenuItem.Click += new System.EventHandler(this.danhMụcSảnPhẩmToolStripMenuItem_Click);
            // 
            // danhMụcHóaĐơnToolStripMenuItem
            // 
            this.danhMụcHóaĐơnToolStripMenuItem.Name = "danhMụcHóaĐơnToolStripMenuItem";
            this.danhMụcHóaĐơnToolStripMenuItem.Size = new System.Drawing.Size(217, 22);
            this.danhMụcHóaĐơnToolStripMenuItem.Text = "Danh mục Hóa Đơn";
            this.danhMụcHóaĐơnToolStripMenuItem.Click += new System.EventHandler(this.danhMụcHóaĐơnToolStripMenuItem_Click);
            // 
            // danhMụcChiTiếtHóaĐơnToolStripMenuItem
            // 
            this.danhMụcChiTiếtHóaĐơnToolStripMenuItem.Name = "danhMụcChiTiếtHóaĐơnToolStripMenuItem";
            this.danhMụcChiTiếtHóaĐơnToolStripMenuItem.Size = new System.Drawing.Size(217, 22);
            this.danhMụcChiTiếtHóaĐơnToolStripMenuItem.Text = "Danh mục Chi tiết hóa đơn";
            this.danhMụcChiTiếtHóaĐơnToolStripMenuItem.Click += new System.EventHandler(this.danhMụcChiTiếtHóaĐơnToolStripMenuItem_Click);
            // 
            // quảnLýDanhMụcĐơnToolStripMenuItem
            // 
            this.quảnLýDanhMụcĐơnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.danhMụcThànhPhốToolStripMenuItem1,
            this.danhMụcKháchHàngToolStripMenuItem1,
            this.danhMụcNhânViênToolStripMenuItem1,
            this.danhMụcSảnPhẩmToolStripMenuItem1,
            this.danhMụcHóaĐơnToolStripMenuItem1,
            this.danhMụcChiTiếtHóaĐơnToolStripMenuItem1});
            this.quảnLýDanhMụcĐơnToolStripMenuItem.Name = "quảnLýDanhMụcĐơnToolStripMenuItem";
            this.quảnLýDanhMụcĐơnToolStripMenuItem.Size = new System.Drawing.Size(118, 20);
            this.quảnLýDanhMụcĐơnToolStripMenuItem.Text = "Quản lý Danh mục";
            // 
            // danhMụcThànhPhốToolStripMenuItem1
            // 
            this.danhMụcThànhPhốToolStripMenuItem1.Name = "danhMụcThànhPhốToolStripMenuItem1";
            this.danhMụcThànhPhốToolStripMenuItem1.Size = new System.Drawing.Size(217, 22);
            this.danhMụcThànhPhốToolStripMenuItem1.Text = "Danh mục Thành phố";
            this.danhMụcThànhPhốToolStripMenuItem1.Click += new System.EventHandler(this.danhMụcThànhPhốToolStripMenuItem1_Click);
            // 
            // danhMụcKháchHàngToolStripMenuItem1
            // 
            this.danhMụcKháchHàngToolStripMenuItem1.Name = "danhMụcKháchHàngToolStripMenuItem1";
            this.danhMụcKháchHàngToolStripMenuItem1.Size = new System.Drawing.Size(217, 22);
            this.danhMụcKháchHàngToolStripMenuItem1.Text = "Danh mục khách hàng";
            this.danhMụcKháchHàngToolStripMenuItem1.Click += new System.EventHandler(this.danhMụcKháchHàngToolStripMenuItem1_Click);
            // 
            // danhMụcNhânViênToolStripMenuItem1
            // 
            this.danhMụcNhânViênToolStripMenuItem1.Name = "danhMụcNhânViênToolStripMenuItem1";
            this.danhMụcNhânViênToolStripMenuItem1.Size = new System.Drawing.Size(217, 22);
            this.danhMụcNhânViênToolStripMenuItem1.Text = "Danh mục Nhân viên";
            // 
            // danhMụcSảnPhẩmToolStripMenuItem1
            // 
            this.danhMụcSảnPhẩmToolStripMenuItem1.Name = "danhMụcSảnPhẩmToolStripMenuItem1";
            this.danhMụcSảnPhẩmToolStripMenuItem1.Size = new System.Drawing.Size(217, 22);
            this.danhMụcSảnPhẩmToolStripMenuItem1.Text = "Danh mục Sản phẩm";
            // 
            // danhMụcHóaĐơnToolStripMenuItem1
            // 
            this.danhMụcHóaĐơnToolStripMenuItem1.Name = "danhMụcHóaĐơnToolStripMenuItem1";
            this.danhMụcHóaĐơnToolStripMenuItem1.Size = new System.Drawing.Size(217, 22);
            this.danhMụcHóaĐơnToolStripMenuItem1.Text = "Danh mục Hóa đơn";
            this.danhMụcHóaĐơnToolStripMenuItem1.Click += new System.EventHandler(this.danhMụcHóaĐơnToolStripMenuItem1_Click);
            // 
            // danhMụcChiTiếtHóaĐơnToolStripMenuItem1
            // 
            this.danhMụcChiTiếtHóaĐơnToolStripMenuItem1.Name = "danhMụcChiTiếtHóaĐơnToolStripMenuItem1";
            this.danhMụcChiTiếtHóaĐơnToolStripMenuItem1.Size = new System.Drawing.Size(217, 22);
            this.danhMụcChiTiếtHóaĐơnToolStripMenuItem1.Text = "Danh mục Chi tiết hóa đơn";
            // 
            // quảnLýDanhMụcTheoNhómToolStripMenuItem
            // 
            this.quảnLýDanhMụcTheoNhómToolStripMenuItem.Name = "quảnLýDanhMụcTheoNhómToolStripMenuItem";
            this.quảnLýDanhMụcTheoNhómToolStripMenuItem.Size = new System.Drawing.Size(12, 20);
            // 
            // giúpĐỡToolStripMenuItem
            // 
            this.giúpĐỡToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hướngDẫnSửDụngToolStripMenuItem,
            this.tácGiảToolStripMenuItem});
            this.giúpĐỡToolStripMenuItem.Name = "giúpĐỡToolStripMenuItem";
            this.giúpĐỡToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.giúpĐỡToolStripMenuItem.Text = "Giúp đỡ";
            // 
            // hướngDẫnSửDụngToolStripMenuItem
            // 
            this.hướngDẫnSửDụngToolStripMenuItem.Name = "hướngDẫnSửDụngToolStripMenuItem";
            this.hướngDẫnSửDụngToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.hướngDẫnSửDụngToolStripMenuItem.Text = "Hướng dẫn sử dụng";
            // 
            // tácGiảToolStripMenuItem
            // 
            this.tácGiảToolStripMenuItem.Name = "tácGiảToolStripMenuItem";
            this.tácGiảToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.tácGiảToolStripMenuItem.Text = "Tác giả";
            this.tácGiảToolStripMenuItem.Click += new System.EventHandler(this.tácGiảToolStripMenuItem_Click);
            // 
            // kháchHàngTheoThànhPhốToolStripMenuItem
            // 
            this.kháchHàngTheoThànhPhốToolStripMenuItem.Name = "kháchHàngTheoThànhPhốToolStripMenuItem";
            this.kháchHàngTheoThànhPhốToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // hóaĐơnTheoKháchHàngToolStripMenuItem
            // 
            this.hóaĐơnTheoKháchHàngToolStripMenuItem.Name = "hóaĐơnTheoKháchHàngToolStripMenuItem";
            this.hóaĐơnTheoKháchHàngToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // hóaĐơnTheoSảnPhẩmToolStripMenuItem
            // 
            this.hóaĐơnTheoSảnPhẩmToolStripMenuItem.Name = "hóaĐơnTheoSảnPhẩmToolStripMenuItem";
            this.hóaĐơnTheoSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // hóaĐơnTheoNhânViênToolStripMenuItem
            // 
            this.hóaĐơnTheoNhânViênToolStripMenuItem.Name = "hóaĐơnTheoNhânViênToolStripMenuItem";
            this.hóaĐơnTheoNhânViênToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // chiTiếtHóaĐơnTheoHóaĐơnToolStripMenuItem
            // 
            this.chiTiếtHóaĐơnTheoHóaĐơnToolStripMenuItem.Name = "chiTiếtHóaĐơnTheoHóaĐơnToolStripMenuItem";
            this.chiTiếtHóaĐơnTheoHóaĐơnToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(394, 109);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(246, 207);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(252, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "(Build 1.0)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(40, 87);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(136, 13);
            this.label9.TabIndex = 14;
            this.label9.Text = "Lê Hoàng Thiên B1906769";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(40, 58);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(165, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Nguyễn Thanh Quang B1906749";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(40, 32);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(157, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Nguyễn Quang Minh B1906520";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 184);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "04/2022";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 162);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(211, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Bộ môn: CNPM, Khoa CNTT và TT, ĐHCT";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Lớp: Bảo Trì Phần Mềm";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Người thực hiện: ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(652, 328);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Màn hình chính";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hệThốngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cấuHìnhHệThốngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýNgườiDùngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đăngNhậpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đổiMậtKhẩuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xemDanhMụcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhMụcThànhPhốToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhMụcKháchHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhMụcNhânViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhMụcSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhMụcHóaĐơnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhMụcChiTiếtHóaĐơnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýDanhMụcĐơnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhMụcThànhPhốToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem danhMụcKháchHàngToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem danhMụcNhânViênToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem danhMụcSảnPhẩmToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem danhMụcHóaĐơnToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem danhMụcChiTiếtHóaĐơnToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem quảnLýDanhMụcTheoNhómToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kháchHàngTheoThànhPhốToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hóaĐơnTheoKháchHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hóaĐơnTheoSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hóaĐơnTheoNhânViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chiTiếtHóaĐơnTheoHóaĐơnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem giúpĐỡToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hướngDẫnSửDụngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tácGiảToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}